import cv2
import math
import numpy as np

def read_image(filename): 
    image = cv2.imread(filename)
    image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
    return image
    
def resize_image(image,width,height):
    rows, cols, channels = image.shape
    w = int(math.ceil(cols*width/100))
    h = int(math.ceil(rows*height/100))
    new_size = (w,h)
    image = cv2.resize(image,new_size)
    return image

def average_filter(image,kernel_size):
    
    return image

def gaussian_filter(image,kernel_size):
    
    return image

def median_filter(image,kernel_size):
    
    return image

def salt_and_pepper_noise(image):
    #h (rows), w (cols)
    h,w, c = image.shape
    noise = np.zeros((h,w),np.uint8)
    cv2.randu(noise,0,255)
    image[noise <= 5] = 0
    image[noise >= 250] = 255
    return image

def sobel_filter(image):
   
    return image
    

def laplacian_filter(image):
    
    return image

def highboost_filter(image,a):
   
    return image
